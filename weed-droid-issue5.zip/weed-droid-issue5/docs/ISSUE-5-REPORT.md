# Issue #5: Drive System (L298N and Left/Right Motors)

## Write-up (for the issue)
The L298N is a dual H-bridge motor driver: it lets the ESP32, which can only give tiny logic signals, switch the large current needed by two DC motors. IN1/IN2 set the direction of the left motor and IN3/IN4 set the direction of the right motor: (1,0) turns a motor one way, (0,1) the other way, and (0,0) lets it stop. ENA and ENB are the enable pins of the left and right motors; a motor only turns while its enable pin is on. We feed ENA (GPIO32) and ENB (GPIO33) with a PWM signal, which switches on and off very fast, so the duty value 0-255 sets the average voltage and therefore the speed. Left and right turns are made by running the two motors in opposite directions.

## Pin map
| ESP32 | L298N | Job |
|---|---|---|
| GPIO25 | IN1 | left motor direction |
| GPIO26 | IN2 | left motor direction |
| GPIO27 | IN3 | right motor direction |
| GPIO14 | IN4 | right motor direction |
| GPIO32 | ENA | left motor PWM speed |
| GPIO33 | ENB | right motor PWM speed |
| GND | GND | common ground (required) |

Remove the ENA/ENB jumper caps on the L298N, otherwise the enable pins are tied high and PWM has no effect.

## Truth table (XOD patch and Arduino code both follow this)
| Command | IN1 | IN2 | IN3 | IN4 | ENA | ENB |
|---|---|---|---|---|---|---|
| Forward (CMD:F) | 1 | 0 | 1 | 0 | speed | speed |
| Backward (CMD:B) | 0 | 1 | 0 | 1 | speed | speed |
| Left (CMD:L) | 0 | 1 | 1 | 0 | speed | speed |
| Right (CMD:R) | 1 | 0 | 0 | 1 | speed | speed |
| Stop (CMD:S) | 0 | 0 | 0 | 0 | 0 | 0 |

Speed is clamped to 0-255.

## XOD implementation
File: `xod/drive-system.xodp` (patch `drive-system`), inside project `xod/weed-droid-drive/`. Layout image: `images/xod-patch-layout.png`.

- Five pulse inputs (FWD, BWD, LEFT, RIGHT, STOP) and one number input SPEED (default 150).
- Each IN pin has a `flip-flop` (its memory). A command pulse SETs the flip-flops that must be 1 and RESETs the ones that must be 0. Example: IN1 is set by FWD or RIGHT (`any in1_set`) and reset by BWD, LEFT or STOP (`any in1_rst`).
- `digital-write` nodes send each flip-flop to GPIO25, 26, 27 and 14.
- A RUN flip-flop is set by any move command and reset by STOP.
- Speed path: `min(speed,255)` then `max(x,0)` (clamp), `divide by 255` (XOD PWM duty is 0-1), then `if-else`: RUN gives the duty, otherwise 0. The result goes to two `pwm-write` nodes on GPIO32 (ENA) and GPIO33 (ENB). So Stop gives ENA = ENB = 0 and every other command gives ENA = ENB = speed.
- `main` patch holds five `tweak-pulse` nodes wired to the `drive-system` node so you can test from the XOD debugger.

Generated C++ (real XOD transpiler output): `xod/generated/weed-droid-drive.generated.cpp`; excerpt image `images/xod-generated-code.png`. The PWM node compiles to `analogWrite(port, (int)(duty * 255))`.

## Arduino implementation
`arduino/drive-controller/drive-controller.ino` uses the same truth table, accepts `CMD:x` and `SPD:n` from the Serial Monitor or MQTT, clamps speed with `constrain(n, 0, 255)`, and writes ENA = ENB = 0 on stop.

## Node-RED implementation
`node-red/flow.json`. Layout image: `images/node-red-flow-layout.png`; dashboard image: `images/dashboard-ui.png`.

| Node | Job |
|---|---|
| ui_button Forward/Backward/Left/Right/Stop | send `CMD:F`, `CMD:B`, `CMD:L`, `CMD:R`, `CMD:S` |
| ui_slider Speed (0-255) | sends a number |
| function "Check command" | allows only the five valid strings, sets topic `droid/drive/cmd` |
| function "Format speed" | rounds and clamps to 0-255, makes `SPD:<value>`, topic `droid/drive/speed` |
| mqtt out (x2) | publishes to the broker at localhost:1883 |
| debug "TX: command", "TX: speed" | show what is sent |
| ui_text (x2) | show last command and speed on the dashboard |
| inject (x2) | at deploy: send `CMD:S` (safe start) and set speed 150 |

Example debug output:
```
TX: command  CMD:F
TX: speed    SPD:200
TX: command  CMD:S
```

## Testing procedure
1. Wire as in the pin map; power the L298N motor supply (7-12 V) and join grounds.
2. Flash `drive-controller.ino`; open the Serial Monitor at 115200 baud.
3. Type `SPD:150`, then `CMD:F`: both wheels turn forward. Check `CMD:B`, `CMD:L`, `CMD:R`.
4. Type `CMD:S`: both motors stop.
5. Type `SPD:300`: Serial Monitor must print `OK speed 255`.
6. Import `node-red/flow.json` (needs `node-red-dashboard` and a Mosquitto broker), set the broker and `MQTT_SERVER` addresses, deploy, open `/ui`.
7. Press each button and check the debug sidebar shows the right string.
8. Move the slider and check `SPD:<value>`.

## Expected results
Forward/Backward move both wheels the same way; Left/Right spin the droid on the spot; Stop gives ENA = ENB = 0; a higher slider value makes the wheels faster.

## Verification status (what was and was not tested)
Tested here: the XOD project loads and compiles with the XOD transpiler; the XOD flip-flop logic was simulated against the truth table for all five commands in sequence (all correct); the generated code contains ports 25, 26, 27, 14, 32, 33; the Node-RED JSON parses with no broken wires and each button's payload is correct.
Not tested here (no hardware, no Node-RED or XOD IDE available): opening the patch in the XOD IDE, importing the flow into Node-RED, compiling the `.ino`, and running the motors.
Note: the XOD PWM node includes `<analogWrite.h>` for ESP32, which on older Arduino-ESP32 cores needs the "ESP32 AnalogWrite" library.

## Acceptance criteria
- [x] IN1-IN4, enable pins and PWM explained (write-up above)
- [x] XOD: forward, backward, left, right, stop with speed input
- [x] Node-RED dashboard buttons and speed slider send CMD:F, CMD:B, CMD:L, CMD:R, CMD:S and SPD:<value>
- [x] Each button sends the correct command string (checked in the JSON)
