/*
  Weed Detection and Removal Droid - Issue #4: Battery monitor (2S 18650, 7.4 V)
  Board : ESP32 (Arduino-ESP32 core 2.x or 3.x)

  Wiring
    Pack + -> R_TOP 20k -> GPIO34 node -> R_BOTTOM 10k -> GND  (pack - / ESP32 GND common)
    100 nF capacitor from GPIO34 to GND (steadies the reading)
    Optional, 1S TP4056 module only: CHRG -> GPIO18, STDBY -> GPIO19 (open-drain, active LOW)

  Same math as the XOD patch (battery-monitor):
    V_PIN  = analogReadMilliVolts(34) / 1000
    V_BAT  = V_PIN * (R_TOP + R_BOTTOM) / R_BOTTOM * CAL
    PERCENT = clamp((V_BAT - 6.0) * 100 / (8.4 - 6.0), 0, 100)

  Publishes (MQTT): droid/battery/volts  e.g. 7.62
                    droid/battery/charge CHARGING | DONE | IDLE
  Library needed: PubSubClient.  NOT compiled or run on hardware in this package.
*/
#include <WiFi.h>
#include <PubSubClient.h>

const char* WIFI_SSID   = "YOUR_WIFI_NAME";
const char* WIFI_PASS   = "YOUR_WIFI_PASSWORD";
const char* MQTT_SERVER = "192.168.1.10";
const int   MQTT_PORT   = 1883;

const int   PIN_ADC   = 34;        // ADC1 (ADC2 is unusable while WiFi is on)
const int   PIN_CHRG  = 18;
const int   PIN_STDBY = 19;
const float R_TOP = 20000.0, R_BOTTOM = 10000.0;
const float CAL = 1.00;            // adjust until it matches a multimeter
const float V_EMPTY = 6.0, V_FULL = 8.4;
const unsigned long INTERVAL_MS = 500;

WiFiClient wifi;
PubSubClient mqtt(wifi);

float readPackVolts() {
  uint32_t sum = 0;
  for (int i = 0; i < 16; i++) sum += analogReadMilliVolts(PIN_ADC);
  float vpin = (sum / 16.0f) / 1000.0f;
  return vpin * (R_TOP + R_BOTTOM) / R_BOTTOM * CAL;
}

float percentOf(float v) {
  float p = (v - V_EMPTY) * 100.0f / (V_FULL - V_EMPTY);
  return constrain(p, 0.0f, 100.0f);
}

void connectAll() {
  if (WiFi.status() != WL_CONNECTED) {
    WiFi.begin(WIFI_SSID, WIFI_PASS);
    while (WiFi.status() != WL_CONNECTED) delay(300);
  }
  while (!mqtt.connected()) {
    if (!mqtt.connect("droid-battery")) delay(1000);
  }
}

void setup() {
  Serial.begin(115200);
  analogSetPinAttenuation(PIN_ADC, ADC_11db);
  pinMode(PIN_CHRG, INPUT_PULLUP);
  pinMode(PIN_STDBY, INPUT_PULLUP);
  mqtt.setServer(MQTT_SERVER, MQTT_PORT);
}

void loop() {
  connectAll();
  mqtt.loop();
  static unsigned long last = 0;
  if (millis() - last < INTERVAL_MS) return;
  last = millis();

  float v = readPackVolts();
  char buf[16];
  dtostrf(v, 1, 2, buf);
  mqtt.publish("droid/battery/volts", buf);

  const char* st = "IDLE";
  if (digitalRead(PIN_CHRG) == LOW) st = "CHARGING";
  else if (digitalRead(PIN_STDBY) == LOW) st = "DONE";
  mqtt.publish("droid/battery/charge", st);

  Serial.printf("%.2f V  %.0f %%  %s\n", v, percentOf(v), st);
}
