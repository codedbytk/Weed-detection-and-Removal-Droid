# Issue #4: Battery Pack (2S 18650) and TP4056 Charging

## Write-up (for the issue)
Two 18650 Li-ion cells connected in series add their voltages: each cell is 3.0 V (empty) to 4.2 V (full), so the pack is 6.0-8.4 V (7.4 V nominal) while the capacity stays that of one cell. The TP4056 is a charger for a SINGLE Li-ion cell: it charges with constant current (up to 1 A, set by a resistor) until the cell reaches 4.2 V, then holds 4.2 V until the current drops, and its CHRG and STDBY pins show charging and done. It does NOT suit a 2-cell series pack: the pack is 8.4 V, above the TP4056 limit, and it cannot balance the cells, so a 2S pack needs a 2S charger/BMS (8.4 V CC/CV, with balancing and protection). The TP4056 only fits if each cell is charged separately (one module per cell, cells not in series while charging) or if the cells are wired in parallel (1S2P, 3.7 V). The ESP32 reads the pack through a 20k/10k voltage divider (8.4 V becomes 2.8 V on the ADC pin), the code multiplies it back, and maps 6.0-8.4 V to 0-100 %.

## Wiring
| Part | Connection |
|---|---|
| Pack + | R_TOP 20 kOhm to GPIO34 |
| GPIO34 | R_BOTTOM 10 kOhm to GND, plus 100 nF to GND |
| Pack - | common GND with the ESP32 |
| Optional 1S TP4056 module | CHRG to GPIO18, STDBY to GPIO19 (open-drain, LOW = active) |

GPIO34 is ADC1 (input-only); ADC2 pins cannot be used while WiFi is on. Divider ratio 1/3: 8.4 V gives 2.80 V, safely under the ESP32 11 dB range (about 3.1 V).

## Voltage table
| Pack | At ADC pin | Percent | Level (threshold 6.6 V) |
|---|---|---|---|
| 8.4 V | 2.80 V | 100 % | FULL |
| 7.8 V | 2.60 V | 75 % | OK |
| 7.2 V | 2.40 V | 50 % | OK |
| 6.6 V | 2.20 V | 25 % | OK |
| 6.5 V | 2.17 V | 21 % | LOW + alert |
| 6.0 V | 2.00 V | 0 % | LOW |

Percent = clamp((V - 6.0) x 100 / 2.4, 0, 100). This is a linear estimate; Li-ion discharge is not linear, so treat percent as approximate.

## XOD implementation
Open `xod/battery-monitor.xodball` in the XOD IDE (File > Open Project). The same project as folders is `xod/weed-droid-battery/`; `xod/battery-monitor.xodp` is the single patch file for the issue, and the IDE cannot open a lone .xodp. Layout image: `images/xod-patch-layout.png`; code image: `images/xod-generated-code.png`.

| Patch | Type | Job |
|---|---|---|
| `adc-read-volts` | native C++ | PIN, INTERVAL (ms) -> V at the pin; 16-sample average, `analogReadMilliVolts` on ESP32, self-timed |
| `divider-scale` | native C++ | V_PIN, R_TOP, R_BOTTOM, CAL -> V_BAT = V_PIN x (Rt+Rb)/Rb x CAL |
| `battery-percent` | native C++ | V_BAT, V_EMPTY (6.0), V_FULL (8.4) -> PERCENT 0-100, clamped |
| `battery-monitor` | visual | inputs ADC_PIN 34, R_TOP 20000, R_BOTTOM 10000, CAL 1.0, V_EMPTY, V_FULL; outputs VOLTS, PERCENT |
| `main` | visual | holds one `battery-monitor` node |

Native nodes were used because their pin keys are the terminal ids, which keeps the project self-contained and readable. `xod/generated/weed-droid-battery.native-nodes.cpp` lists the three native bodies.

## Arduino companion
`arduino/battery-monitor/battery-monitor.ino` does the same math and publishes `droid/battery/volts` and `droid/battery/charge` (CHARGING / DONE / IDLE) by MQTT every 500 ms.

## Node-RED implementation
`node-red/battery-gauge.json`. Layout image: `images/node-red-flow-layout.png`; dashboard image: `images/dashboard-ui.png`.

| Node | Job |
|---|---|
| mqtt in `droid/battery/volts` | real pack voltage from the ESP32 |
| ui_button "Simulate 8.4 V to 6.0 V" + function + delay | 25 values, 8.4 down to 6.0 in 0.1 V steps, 2 per second |
| function "Battery logic" | percent, level (FULL >= 90 %, OK, LOW below threshold), one alert |
| ui_gauge, ui_text x2 | percent gauge, pack voltage, level |
| ui_toast + debug ALERT | low-battery alert |
| ui_numeric "Low-battery threshold" | set point 6.0-8.4 V, default 6.6 V, stored in flow context |
| mqtt in `droid/battery/charge`, ui_dropdown, function, ui_template | charge indicator: CHARGING (amber), CHARGED (green), NOT CHARGING (grey) |

Alert rule: fires once when the voltage first goes below the threshold, then stays quiet until the voltage rises above threshold + 0.2 V, so noise around the threshold cannot spam alerts.

## Testing procedure
1. Wire as above; flash the sketch (or deploy the XOD project).
2. Compare Serial Monitor volts with a multimeter; adjust CAL until they match.
3. Import `node-red/battery-gauge.json` (needs `node-red-dashboard` and Mosquitto), set the broker, deploy, open `/ui`.
4. Press "Simulate 8.4 V to 6.0 V": the gauge falls from 100 % to 0 %, the level goes FULL, OK, LOW, and exactly one toast and one ALERT debug message appear.
5. Change the charger dropdown: the indicator changes colour.

## Verification status (what was and was not tested)
Tested here: all `fn_*` function-node bodies from the flow were run in Node.js with a mocked `flow`/`msg`: the 25-step sweep gives 100 % FULL at 8.4 V and 0 % LOW at 6.0 V with exactly 1 alert (at 6.5 V); bouncing around the threshold gives 0 extra alerts; re-arm works; invalid input is ignored; the flow JSON parses with no broken wires. The scaling and percent formulas were compiled in C++ and give the table above (pin voltage never above 2.80 V).
Not tested (no XOD IDE/CLI, Node-RED, ESP32 or hardware available): opening the XOD project in the IDE, transpiling it, importing the flow into Node-RED, compiling the `.ino`, real ADC accuracy. The images are rendered layout diagrams, not screenshots of the real tools; please replace them with real screenshots once you open the files. The XOD native-node API calls (`isTimedOut`, `setTimeout`, `emitValue`) follow XOD's documented pattern but should be confirmed in the IDE.

## Acceptance criteria
- [x] 18650 series pack and TP4056 explained, including that it does not suit a 2S pack
- [x] XOD: divider on ADC pin, scaled, volts and percent outputs
- [x] Node-RED: gauge, low-battery alert, charge status indicator
- [x] Simulated 8.4 V to 6.0 V shows full to low and triggers one alert (checked by running the flow functions)
