// Linear map V_EMPTY..V_FULL -> 0..100 %, clamped.  2S Li-ion: 6.0 V .. 8.4 V.
node {
    void evaluate(Context ctx) {
        double v = getValue<input_V_BAT>(ctx);
        double lo = getValue<input_V_EMPTY>(ctx);
        double hi = getValue<input_V_FULL>(ctx);
        if (hi <= lo) return;                              // invalid range
        double p = (v - lo) * 100.0 / (hi - lo);
        if (p < 0) p = 0;
        if (p > 100) p = 100;
        emitValue<output_PERCENT>(ctx, p);
    }
}
