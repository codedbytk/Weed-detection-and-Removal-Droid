// Reads an ADC pin, averages 16 samples and emits the voltage AT THE PIN in volts.
// Re-reads every INTERVAL milliseconds (self-timed, no clock node needed).
node {
    void evaluate(Context ctx) {
        if (!isInputDirty<input_INTERVAL>(ctx) && !isTimedOut(ctx))
            return;

        int pin = (int)getValue<input_PIN>(ctx);
        uint32_t sum = 0;
        const int N = 16;
#ifdef ESP32
        analogSetPinAttenuation(pin, ADC_11db);          // range ~0..3.1 V
        for (int i = 0; i < N; i++) sum += analogReadMilliVolts(pin);
        double volts = (sum / (double)N) / 1000.0;       // calibrated mV -> V
#else
        for (int i = 0; i < N; i++) sum += analogRead(pin);
        double volts = (sum / (double)N) * 5.0 / 1023.0; // 5 V AVR fallback
#endif
        emitValue<output_V>(ctx, volts);

        TimeMs dt = (TimeMs)getValue<input_INTERVAL>(ctx);
        setTimeout(ctx, dt < 50 ? 50 : dt);
    }
}
