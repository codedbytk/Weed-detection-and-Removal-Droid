// Undo the voltage divider:  V_BAT = V_PIN * (R_TOP + R_BOTTOM) / R_BOTTOM * CAL
// CAL is a multimeter calibration factor (1.0 = no correction).
node {
    void evaluate(Context ctx) {
        double vpin = getValue<input_V_PIN>(ctx);
        double rt   = getValue<input_R_TOP>(ctx);
        double rb   = getValue<input_R_BOTTOM>(ctx);
        double cal  = getValue<input_CAL>(ctx);
        if (rb <= 0) return;                               // invalid divider
        emitValue<output_V_BAT>(ctx, vpin * (rt + rb) / rb * cal);
    }
}
