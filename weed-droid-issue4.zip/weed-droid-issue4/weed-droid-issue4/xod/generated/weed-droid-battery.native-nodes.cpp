// Native node bodies of the weed-droid-battery XOD project, concatenated for review.
// NOT real XOD transpiler output (the XOD IDE/CLI was not available when this was written).
// In the IDE, Deploy > Show code for Arduino generates the full sketch around these bodies.

// ===== @/adc-read-volts =====
// Reads an ADC pin, averages 16 samples and emits the voltage AT THE PIN in volts.
// Re-reads every INTERVAL milliseconds (self-timed, no clock node needed).
node {
    void evaluate(Context ctx) {
        if (!isInputDirty<input_INTERVAL>(ctx) && !isTimedOut(ctx))
            return;

        int pin = (int)getValue<input_PIN>(ctx);
        uint32_t sum = 0;
        const int N = 16;
#ifdef ESP32
        analogSetPinAttenuation(pin, ADC_11db);          // range ~0..3.1 V
        for (int i = 0; i < N; i++) sum += analogReadMilliVolts(pin);
        double volts = (sum / (double)N) / 1000.0;       // calibrated mV -> V
#else
        for (int i = 0; i < N; i++) sum += analogRead(pin);
        double volts = (sum / (double)N) * 5.0 / 1023.0; // 5 V AVR fallback
#endif
        emitValue<output_V>(ctx, volts);

        TimeMs dt = (TimeMs)getValue<input_INTERVAL>(ctx);
        setTimeout(ctx, dt < 50 ? 50 : dt);
    }
}

// ===== @/divider-scale =====
// Undo the voltage divider:  V_BAT = V_PIN * (R_TOP + R_BOTTOM) / R_BOTTOM * CAL
// CAL is a multimeter calibration factor (1.0 = no correction).
node {
    void evaluate(Context ctx) {
        double vpin = getValue<input_V_PIN>(ctx);
        double rt   = getValue<input_R_TOP>(ctx);
        double rb   = getValue<input_R_BOTTOM>(ctx);
        double cal  = getValue<input_CAL>(ctx);
        if (rb <= 0) return;                               // invalid divider
        emitValue<output_V_BAT>(ctx, vpin * (rt + rb) / rb * cal);
    }
}

// ===== @/battery-percent =====
// Linear map V_EMPTY..V_FULL -> 0..100 %, clamped.  2S Li-ion: 6.0 V .. 8.4 V.
node {
    void evaluate(Context ctx) {
        double v = getValue<input_V_BAT>(ctx);
        double lo = getValue<input_V_EMPTY>(ctx);
        double hi = getValue<input_V_FULL>(ctx);
        if (hi <= lo) return;                              // invalid range
        double p = (v - lo) * 100.0 / (hi - lo);
        if (p < 0) p = 0;
        if (p > 100) p = 100;
        emitValue<output_PERCENT>(ctx, p);
    }
}
